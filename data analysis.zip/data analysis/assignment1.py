import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.metrics import confusion_matrix, classification_report
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
data = pd.read_csv("bava.csv")

# Remove NaN and non-numeric RD_Value entries
data = data[data['RD_Value'].notna()]
data = data[data['RD_Value'].str.replace('.', '', regex=False).str.isnumeric()]

# Convert RD_Value to float
data['RD_Value'] = data['RD_Value'].astype(float)

# Create binary target: high_rd_spending (1 if above median)
median_val = data['RD_Value'].median()
data['high_rd_spending'] = (data['RD_Value'] > median_val).astype(int)

# Encode categorical columns
categorical_cols = ['Variable', 'Breakdown', 'Breakdown_category', 'Unit']
for col in categorical_cols:
    data[col] = LabelEncoder().fit_transform(data[col])

# Features and Target
features = categorical_cols + ['Year']
X = StandardScaler().fit_transform(data[features])
y = data['high_rd_spending']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train Random Forest Classifier
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.tight_layout()
plt.show()

# Classification Report
print("\n📊 Classification Report:\n", classification_report(y_test, y_pred))

# Prosentropy Error
def prosentropy_error(y_true, y_pred):
    errors = y_true != y_pred
    percent_error = np.mean(errors) * 100
    entropy = -np.sum(errors * np.log2(np.random.rand(len(errors)) + 1e-9)) / len(errors)
    return round(percent_error, 2), round(entropy, 4)

err, entropy = prosentropy_error(y_test, y_pred)
print(f"\n⚠ Prosentropy Error:\n - % Error: {err}%\n - Entropy: {entropy}")

# K-Fold Validation
kfold = KFold(n_splits=10, shuffle=True, random_state=1)
scores = cross_val_score(model, X, y, cv=kfold)
print("\n🔁 10-Fold Accuracy Scores:", scores)
print("📈 Average Accuracy:", round(scores.mean(), 4))

# Accuracy with different splits
print("\n📚 Accuracy with different splits:")
for r in [0.2, 0.3, 0.4]:
    X_train_r, X_test_r, y_train_r, y_test_r = train_test_split(X, y, test_size=r, random_state=42)
    model.fit(X_train_r, y_train_r)
    acc = model.score(X_test_r, y_test_r)
    print(f"{int((1-r)*100)}:{int(r*100)} split → Accuracy: {round(acc, 4)}")
