import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns

# Step 1: Load dataset
data = pd.read_csv("bava.csv")

# Step 2: Clean RD_Value
data = data[data['RD_Value'].notna()]
data = data[data['RD_Value'].str.replace('.', '', regex=False).str.isnumeric()]
data['RD_Value'] = data['RD_Value'].astype(float)

# Step 3: Create binary target (1 if RD_Value > median)
median_val = data['RD_Value'].median()
data['target'] = (data['RD_Value'] > median_val).astype(int)

# Step 4: Encode categorical columns
for col in ['Variable', 'Breakdown', 'Breakdown_category', 'Unit']:
    data[col] = LabelEncoder().fit_transform(data[col].astype(str))

# Step 5: Feature selection
features = ['Variable', 'Breakdown', 'Breakdown_category', 'Unit', 'Year']
X = StandardScaler().fit_transform(data[features])
y = data['target']

# Step 6: Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)

# Step 7: Train model
model = RandomForestClassifier(random_state=0)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Step 8: Evaluation
print("📊 Classification Report:\n")
print(classification_report(y_test, y_pred))

# Step 9: Enhanced Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
labels = ['Low Spending (0)', 'High Spending (1)']

plt.figure(figsize=(6, 4))
sns.heatmap(cm, annot=True, fmt='d', cmap='YlGnBu', xticklabels=labels, yticklabels=labels, cbar=False)
plt.title("🧩 Confusion Matrix - R&D Spending Classification")
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.tight_layout()
plt.show()
